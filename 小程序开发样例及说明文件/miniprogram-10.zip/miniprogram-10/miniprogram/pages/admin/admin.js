var that = undefined;
var doommList = [];
var i = 0;
var ids = 0;
var cycle = null
class Doomm {
  constructor(text, time) {
    this.text = text;
   this.time = time;
    this.display = true;
  }
}
var Bmob = require('../../utils/Bmob-1.7.1.min.js');
Page({
  data: {
    showView: 'ture',
    doommData: [],
  },
  onLoad: function () {
   var  that = this;
    const query = Bmob.Query("WX-tongzhi");
    query.find().then(res => {
        that.setData({
          msgList: [
            { title: res[0].tongzhi },
            { title: res[1].tongzhi },
            { title: res[2].tongzhi }]
        });
    });
  },
})