!function () {
  var t = function (t, a, i) {
    return parseFloat(t) + parseFloat(a) / 60 + parseFloat(i) / 3600;
  }, a = function (a, i, e) {
    return t(a, i, e) * Math.PI / 180;
  };
  Page({
    data: {
      xa: "",
      ya: "",
      ab: "",
      angle: "",
      value: "",
      xb: 0,
      yb: 0
    },
    inputXa: function (t) {
      var a = t.detail.value;
      this.setData({
        xa: a
      });
    },
    inputYa: function (t) {
      var a = t.detail.value;
      this.setData({
        ya: a
      });
    },
    inputAB: function (t) {
      var a = t.detail.value;
      this.setData({
        ab: a
      });
    },
    inputAngle: function (t) {
      var a = t.detail.value;
      this.setData({
        angle: a
      });
    },
    disCalc: function () {
      var t, i, e, n, s, o, l, r = [];
      if (t = this.data.xa, i = this.data.ya, e = this.data.ab, n = this.data.angle, r = n.trim().split(/[ |,|，]/),
        l = a(r[0], r[1], r[2]), 0 != !t.length || 0 != !i.length || 0 != !e.length || 0 != !n.length) wx.showToast({
          title: "请输入完整数据！",
          icon: "none",
          duration: 1500
        }); else if (isNaN(t) || isNaN(i) || isNaN(e)) wx.showToast({
          title: "乖！请填数字",
          icon: "none",
          duration: 1500
        }); else {
        for (var u = 0; u < r.length; u++) if (isNaN(r[u])) return void wx.showToast({
          title: "请输入正确数据！",
          icon: "none",
          duration: 1500
        });
        if (3 !== r.length) return void wx.showToast({
          title: "请检查角度输入格式是否有误。输入格式为：30 30 30",
          icon: "none",
          duration: 2e3
        });
        var h, d, c;
        h = parseFloat(t), d = parseFloat(i), s = (h + (c = parseFloat(e)) * Math.cos(l)).toFixed(4),
          o = d + c * Math.sin(l).toFixed(4), this.setData({
            xb: s,
            yb: o
          });
      }
    },
    clear: function () {
      this.setData({
        value: "",
        xb: 0,
        yb: 0
      });
    }
  });
}();