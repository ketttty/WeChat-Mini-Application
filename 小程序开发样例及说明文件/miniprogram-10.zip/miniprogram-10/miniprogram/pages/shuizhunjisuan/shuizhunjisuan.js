// pages/daoxian/daoxian.js
const app = getApp()
var wa1 = "";
var waa1;
var waaa1;
var waaaa1;
var wb1;
var wbb1;
var wbbb1;
var wbbbb1;
var wc1;
var wcc1;
var wccc1;
var wcccc1;
var wccccc1;
var wd1;
var wdd1;
var wddd1;
var wdddd1;
var we1;
var wf1;
var rt = "";
var rt1 = "";
var rt2 = "";
var rt3 = "";
var rt4 = "";
var rt5 = "";
var rt6 = "";
var rt7 = "";
var rt8 = "";
var rt9 = "";
var rt10 = "";
var rt11 = "";
Page({
  wa: function (t) {
    wa1 = t.detail.value;
  },
  wb: function (t) {
    wb1 = t.detail.value;
  },
  waa: function (t) {
    waa1 = t.detail.value;
  },
  wbb: function (t) {
    wbb1 = t.detail.value;
  },
  waaa: function (t) {
    waaa1 = t.detail.value;
  },
  wbbb: function (t) {
    wbbb1 = t.detail.value;
  },
  waaaa: function (t) {
    waaaa1 = t.detail.value;
  },
  wbbbb: function (t) {
    wbbbb1 = t.detail.value;
  },
  we: function (t) {
    we1 = t.detail.value;
  },
   wf: function (t) {
    wf1 = t.detail.value;
  },
  data: {
    wa: '',
    waa: '',
    wb: '',
    wbb: '',
    waaa: '',
    waaaa: '',
    wbbb: '',
    wbbbb: '',
  },
  cal: function () {
    //后尺视距
    rt = (parseFloat(wa1) - parseFloat(waaa1)) / 10 ;
  //黑面高差
    rt1 = (parseFloat(waa1) - parseFloat(wbb1));
    //前尺视距
    rt2 = (parseFloat(wb1) - parseFloat(wbbb1)) / 10 ;
    //红面高差
    rt3 = (parseFloat(waaaa1) - parseFloat(wbbbb1))  ;
  console.log(rt3)
//后视K+黑-红
    rt8 = parseFloat(waa1) + parseFloat(we1) - parseFloat(waaaa1);
//前视K+黑-红
    rt9 = parseFloat(wbb1) + parseFloat(wf1) - parseFloat(wbbbb1);
    //黑红面高差之差
    rt6 = (parseFloat(rt8) - parseFloat(rt9));
    //视距差
    rt10 = parseFloat(rt) - parseFloat(rt2);
    //平均高差
    if (parseFloat(we1) < parseFloat(wf1)){
      rt7 = (parseFloat(rt3) +(parseFloat(rt1)+100) )/ 2000;
    }else{
      rt7 = (parseFloat(rt3) + (parseFloat(rt1) - 100)) / 2000;
    }
    if (parseFloat(rt) <= 80 && parseFloat(rt2) <= 80 && Math.abs(parseFloat(rt10)) <= 5 && parseFloat(waa1) >= 200 && Math.abs(parseFloat(rt6)) <= 5 && Math.abs(parseFloat(rt8)) <= 3 && Math.abs(parseFloat(rt9)) <= 3){
      rt11="合格"
    }else{
      rt11 = "不合格"
    }
    this.setData({
      wg: "后尺视距:",
      wgg: "前尺视距:",
      wggg: "黑面高差:",
      wgggg: "红面高差:",
      wggggg: "平均高差:",
      wh: "后视K+黑-红:",
      whh: "前视K+黑-红:",
      whhh: "黑红高差之差:",
      whhhh: "视距差:",
      wc: rt + "m",
      wcc: rt2 + "m",
      wccc: rt1,
      wcccc: rt3,
      wccccc: rt7.toFixed(3) + "m",
      wd: rt8,
      wdd: rt9,
      wddd: rt6,
      wdddd: rt10.toFixed(1) + "m",
      wddddd: rt11
     
    })
  },
  clear: function () {
    this.setData({
      'wa': '',
      'waa': '',
      'waaa': '',
      'waaaa': '',
      'wb': '',
      'wbb': '',
      'wbbb': '',
      'wbbbb': '',
     'wg': '',
      'wgg': '',
      'wggg': '',
      'wgggg': '',
      'wggggg': '',
      'wh': '',
      'whh': '',
      'whhh': '',
      'whhhh': '',
      'wc': '',
      'wcc': '',
      'wccc': '',
      'wcccc': '',
      'wccccc': '',
     'wd': '',
     'wdd': '',
      'wddd': '',
      'wdddd': '',
      'wddddd': '',
    })
  },

})