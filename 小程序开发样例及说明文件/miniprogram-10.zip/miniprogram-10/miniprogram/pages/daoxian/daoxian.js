// pages/daoxian/daoxian.js
const app = getApp()
  var wa1 ="";
  var waa1;
  var waaa1;
  var wb1;
  var wbb1;
  var wbbb1 ;
  var wsa1 ;
  var wsaa1 ;
  var wsaaa1;
  var wsb1 ;
  var wsbb1 ;
  var wsbbb1;
  var wsab1;
var r = [];
var r1 = [];
var r2 = [];
var r3 = [];
var rt = "";
var rt1 = "";
var rt2 = "";
var rt3 = "";
var rt4 = "";
var rt5 = "";
var rt6 = "";
var rt7 = "";
var rt8 = "";
var rt9 = "";
var rt10 = "";
var rt11 = "";
var rt12 = "";
var rt13 = "";
  Page({
    wa: function (t) {
      wa1 = t.detail.value;
    },
    wb: function (t) {
      wb1 = t.detail.value;
    },
    waa: function (t) {
      waa1 = t.detail.value;
    },
    wbb: function (t) {
      wbb1 = t.detail.value;
    },
    wsa: function (t) {
      wsa1 = t.detail.value;
    },
    wsaa: function (t) {
      wsaa1 = t.detail.value;
    },
    wsb: function (t) {
      wsb1 = t.detail.value;
    },
    wsbb: function (t) {
      wsbb1 = t.detail.value;
    },
    data:{
      wa: '',
      waa:'',
      wb: '',
      wbb: '',
      wsa: '',
      wsaa: '',
      wsb: '',
      wsbb: '',
      wsbbbb: '',
    },
  cal: function () {
    if (wa1.length < 5 || wb1.length < 5 || waa1.length < 5 || wbb1.length < 5) {
      wx.showToast({
        title: '保证数据完整',
      })
    }else{
      r = wa1.split(/[-|.|——]/);
      r1 = wb1.split(/[-|.|——]/);
      r2 = waa1.split(/[-|.|——]/);
      r3 = wbb1.split(/[-|.|——]/);
      rt = parseFloat(r[0]) + parseFloat(r[1]) / 60 + parseFloat(r[2]) / 3600;
      rt1 = parseFloat(r1[0]) + parseFloat(r1[1]) / 60 + parseFloat(r1[2]) / 3600;
      rt2 = parseFloat(r2[0]) + parseFloat(r2[1]) / 60 + parseFloat(r2[2]) / 3600;
      rt3 = parseFloat(r3[0]) + parseFloat(r3[1]) / 60 + parseFloat(r3[2]) / 3600;
      if (rt > 180) {
        rt4 = parseFloat(rt1) - parseFloat(rt) + 360;
      } else {
        rt4 = parseFloat(rt1) - parseFloat(rt);
      }
      if (rt1 > 180) {
        rt5 = parseFloat(rt3) - parseFloat(rt2) + 360;
      } else {
        rt5 = parseFloat(rt3) - parseFloat(rt2);
      }
      rt6 = (parseFloat(rt5) + parseFloat(rt4)) / 2;
      rt7 = (parseFloat(wsa1) + parseFloat(wsaa1)) / 2;
      rt8 = (parseFloat(wsb1) + parseFloat(wsbb1)) / 2;
      rt9 = parseInt(parseFloat(rt4)).toString() + "°" + parseInt((parseFloat(rt4) - parseInt(parseFloat(rt4))) * 60).toString() + "′" + ((((parseFloat(rt4) - parseInt(parseFloat(rt4))) * 60 - parseInt((parseFloat(rt4) - parseInt(parseFloat(rt4))) * 60)) * 60).toFixed(2).toString()) + "″";
      rt10 = parseInt(parseFloat(rt5)).toString() + "°" + parseInt((parseFloat(rt5) - parseInt(parseFloat(rt5))) * 60).toString() + "′" + ((((parseFloat(rt5) - parseInt(parseFloat(rt5))) * 60 - parseInt((parseFloat(rt5) - parseInt(parseFloat(rt5))) * 60)) * 60).toFixed(2).toString()) + "″";
      rt11 = parseInt(parseFloat(rt6)).toString() + "°" + parseInt((parseFloat(rt6) - parseInt(parseFloat(rt6))) * 60).toString() + "′" + ((((parseFloat(rt6) - parseInt(parseFloat(rt6))) * 60 - parseInt((parseFloat(rt6) - parseInt(parseFloat(rt6))) * 60)) * 60).toFixed(2).toString()) + "″";
      if (Math.abs(parseFloat(rt4) - parseFloat(rt5)) <= 0.011111) {
        rt12 = "合格"
      } else {
        rt12 = "不合格"
      }
      this.setData({
        gggggg: '结果:',
        g :'上半测回差A:',
        gg: '下半测回差B:',
        ggg: '测回差:',
        gggg: '平距A:',
        ggggg: '平距B:',
      waaa: rt9,
        wbbb: rt10,
        wsab: rt11,
        wsbbb: rt8+'m',
        wsaaa: rt7+'m',
        wsbbbb:rt12,
      })
    }
  },
    clear: function () {
      this.setData({
      'wa': '',
      'waa': '',
      'wb': '',
      'wbb': '',
      'wsa': '',
      'wsaa': '',
      'wsb': '',
      'wsbb': '',
      'g': '',
       'gg': '',
        'ggg': '',
       'gggg':'',
        'ggggg': '',
        'gggggg': '',
        'waaa': '',
        'wbbb': '', 
        'wsab': '', 
        'wsbbb': '', 
        'wsaaa': '',
        'wsbbbb': '', 
      })
    }
})