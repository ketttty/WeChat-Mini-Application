var e = function (e) {
  return (e = e.toString())[1] ? e : "0" + e;
};

module.exports = {
  formatTime: function (t) {
    var n = t.getFullYear(), r = t.getMonth() + 1, o = t.getDate(), a = t.getHours(), i = t.getMinutes(), l = t.getSeconds();
    return [n, r, o].map(e).join("/") + " " + [a, i, l].map(e).join(":");
  },
  sumOfAngle: function (e, t) {
    var n = [];
    if (3 == e.length && 3 == t.length) {
      n = [[], [], []];
      var r = parseFloat((e[2] + t[2]).toFixed(3)), o = 0;
      r >= 60 ? (n[2] = parseFloat((r - 60).toFixed(3)), o = 1) : n[2] = r;
      var a = e[1] + t[1] + o, i = 0;
      a >= 60 ? (n[1] = a - 60, i = 1) : n[1] = a;
      var l = e[0] + t[0] + i;
      return n[0] = l, n;
    }
    return 4 == e.length && 4 == t.length ? (e.pop(), t.pop(), (n = this.sumOfAngle(e, t)).push(-1),
      n) : 3 == e.length && 4 == t.length ? (t.pop(), n = this.differenceOfAngle(e, t)) : 4 == e.length && 3 == t.length ? (e.pop(),
        n = this.differenceOfAngle(t, e)) : void 0;
  },
  differenceOfAngle: function (e, t) {
    var n = [[], [], []], r = [], o = [], a = !0;
    e[0] < t[0] ? (o = e, r = t, a = !1) : e[0] == t[0] ? e[1] < t[1] ? (o = e, r = t,
      a = !1) : e[1] == t[1] && e[2] < t[2] ? (o = e, r = t, a = !1) : (o = t, r = e) : (o = t,
        r = e);
    var i = 0;
    r[2] < o[2] ? (n[2] = parseFloat((r[2] + 60 - o[2]).toFixed(3)), i = 1) : (r[2],
      o[2], n[2] = parseFloat((r[2] - o[2]).toFixed(3)));
    var l = 0;
    return r[1] - i < o[1] ? (n[1] = r[1] - i + 60 - o[1], l = 1) : n[1] = r[1] - i - o[1],
      n[0] = r[0] - l - o[0], a ? n : (n.push(-1), n);
  },
  divideOfAngle: function (e, t) {
    var n = [[], [], []], r = e[0] % t;
    n[0] = parseInt(e[0] / t);
    var o = (e[1] + 60 * r) % t;
    return n[1] = parseInt((e[1] + 60 * r) / t), n[2] = parseFloat(((e[2] + 60 * o) / t).toFixed(3)),
      e.length > 3 && n.push(-1), n;
  }
};